'''
__init__.py
'''

import TextOnScreen

__all__ = ["TextOnScreen"]
